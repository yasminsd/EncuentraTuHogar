package com.Encuentra_Tu_Hogar.Encuentra_Tu_Hogar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncuentraTuHogarApplicationTests {

	@Test
	void contextLoads() {
	}

}
