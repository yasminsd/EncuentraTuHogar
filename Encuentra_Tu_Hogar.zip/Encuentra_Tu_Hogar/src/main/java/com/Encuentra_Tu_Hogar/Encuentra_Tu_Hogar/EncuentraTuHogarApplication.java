package com.Encuentra_Tu_Hogar.Encuentra_Tu_Hogar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncuentraTuHogarApplication {

	public static void main(String[] args) {
		SpringApplication.run(EncuentraTuHogarApplication.class, args);
	}

}
